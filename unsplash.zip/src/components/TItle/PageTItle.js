import React from 'react'
import styled from 'styled-components';

const PageTItle = ({title, desc}) => {

    return (
        <Container>
            PageTItle
        </Container>
    )
}


const Container = styled.div`
    
`;

export default PageTItle;