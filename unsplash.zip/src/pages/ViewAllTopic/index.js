import React from 'react';
import styled from 'styled-components';
import TopicListContainer from "../../container/TopicListContainer/TopicListContainer";

const ViewAllTopic = () => {




    return(

        <Container>
            <TopicListContainer></TopicListContainer>
        </Container>

    )

}

const Container = styled.div`
  padding-top: 145px;
    
    
`

export default ViewAllTopic;